// ===================== DonnaBella — shared app (v2) =====================
// Central de configuração — troque pelos links reais antes de publicar.
const SOCIAL_LINKS = {
  instagram: '', // ex: 'https://instagram.com/donnabella'
  tiktok: '',    // ex: 'https://tiktok.com/@donnabella'
  whatsapp: ''   // ex: 'https://wa.me/5511999999999'
};

// Catálogo central — usado por busca, favoritos e sacola.
const PRODUCTS = [
  { id:'brinco-argola-sussurro', name:'Argola Sussurro', price:79.90, category:'Brincos', url:'categoria-brincos.html' },
  { id:'brinco-gota-alma',       name:'Gota Alma',        price:69.90, category:'Brincos', url:'categoria-brincos.html' },
  { id:'brinco-ponto-de-luz',    name:'Ponto de Luz',     price:59.90, category:'Brincos', url:'categoria-brincos.html' },
  { id:'brinco-petit-bella',     name:'Petit Bella',      price:49.90, category:'Brincos', url:'categoria-brincos.html' },
  { id:'brinco-argola-dois-tons',name:'Argola Dois Tons', price:19.90, category:'Brincos', url:'categoria-brincos.html' },
  { id:'brinco-argola-ouro-rose',name:'Argola Ouro Rosé', price:24.90, category:'Brincos', url:'categoria-brincos.html' },
  { id:'brinco-argola-prata',    name:'Argola Prata',     price:22.90, category:'Brincos', url:'categoria-brincos.html' },
  { id:'brinco-petit-com-pedra', name:'Petit com Pedra',  price:21.90, category:'Brincos', url:'categoria-brincos.html' },
  { id:'oculos-sunset-bella',    name:'Óculos Sunset Bella — Sol de Verão', price:69.90, category:'Óculos', url:'categoria-oculos.html', img:'assets/img/oculos-sunset-bella-1.jpg' },
];

const money = v => 'R$ ' + v.toFixed(2).replace('.', ',');

// ---------- localStorage helpers ----------
const Store = {
  get(key, fallback){ try{ const v = JSON.parse(localStorage.getItem(key)); return v ?? fallback; }catch(e){ return fallback; } },
  set(key, val){ try{ localStorage.setItem(key, JSON.stringify(val)); }catch(e){} }
};
const getCart = () => Store.get('db_cart', {});       // { productId: qty }
const setCart = (c) => { Store.set('db_cart', c); updateCartBadge(); };
const getFavorites = () => Store.get('db_favorites', []); // [productId]
const setFavorites = (f) => { Store.set('db_favorites', f); updateFavoriteHearts(); };

function updateCartBadge(){
  const cart = getCart();
  const count = Object.values(cart).reduce((a,b)=>a+b, 0);
  document.querySelectorAll('[data-cart-badge]').forEach(b=>{
    b.textContent = count;
    b.style.display = count > 0 ? 'flex' : 'none';
  });
}
function updateFavoriteHearts(){
  const favs = getFavorites();
  document.querySelectorAll('[data-fav-btn]').forEach(btn=>{
    const id = btn.dataset.favBtn;
    btn.classList.toggle('is-fav', favs.includes(id));
  });
  document.querySelectorAll('[data-fav-badge]').forEach(b=>{
    b.textContent = favs.length;
    b.style.display = favs.length > 0 ? 'flex' : 'none';
  });
}

function addToCart(id, qty=1){
  const cart = getCart();
  cart[id] = (cart[id]||0) + qty;
  setCart(cart);
}
function removeFromCart(id){
  const cart = getCart();
  delete cart[id];
  setCart(cart);
  renderCartPanel();
}
function changeQty(id, delta){
  const cart = getCart();
  if(!cart[id]) return;
  cart[id] += delta;
  if(cart[id] <= 0) delete cart[id];
  setCart(cart);
  renderCartPanel();
}
function toggleFavorite(id){
  let favs = getFavorites();
  if(favs.includes(id)) favs = favs.filter(x=>x!==id);
  else favs.push(id);
  setFavorites(favs);
  renderFavoritesPanel();
}

// ---------- inject shared panels/modal into every page ----------
function injectSharedUI(){
  if(document.getElementById('dbOverlay')) return;
  const wrap = document.createElement('div');
  wrap.innerHTML = `
    <div class="db-overlay" id="dbOverlay"></div>

    <aside class="db-panel" id="cartPanel" aria-label="Sacola">
      <div class="db-panel-head">
        <h3>Sua sacola</h3>
        <button class="drawer-close" data-panel-close aria-label="Fechar sacola">
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M1 1l12 12M13 1L1 13" stroke="currentColor" stroke-width="1.3"/></svg>
        </button>
      </div>
      <div class="db-panel-body" id="cartBody"></div>
      <div class="db-panel-foot" id="cartFoot"></div>
    </aside>

    <aside class="db-panel" id="favPanel" aria-label="Favoritos">
      <div class="db-panel-head">
        <h3>Meus favoritos</h3>
        <button class="drawer-close" data-panel-close aria-label="Fechar favoritos">
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M1 1l12 12M13 1L1 13" stroke="currentColor" stroke-width="1.3"/></svg>
        </button>
      </div>
      <div class="db-panel-body" id="favBody"></div>
    </aside>

    <aside class="db-panel db-modal" id="infoPanel" aria-label="Central de atalhos">
      <div class="db-panel-head">
        <h3 id="infoTitle">DonnaBella</h3>
        <button class="drawer-close" data-panel-close aria-label="Fechar">
          <svg width="14" height="14" viewBox="0 0 14 14"><path d="M1 1l12 12M13 1L1 13" stroke="currentColor" stroke-width="1.3"/></svg>
        </button>
      </div>
      <div class="db-panel-body" id="infoBody"></div>
    </aside>
  `;
  document.body.appendChild(wrap);

  document.getElementById('dbOverlay').addEventListener('click', closeAllPanels);
  document.querySelectorAll('[data-panel-close]').forEach(b=> b.addEventListener('click', closeAllPanels));
}

function closeAllPanels(){
  document.querySelectorAll('.db-panel').forEach(p=>p.classList.remove('open'));
  document.getElementById('dbOverlay')?.classList.remove('open');
  document.body.style.overflow='';
}
function openPanel(id){
  closeAllPanels();
  document.getElementById(id)?.classList.add('open');
  document.getElementById('dbOverlay')?.classList.add('open');
  document.body.style.overflow='hidden';
}

// ---------- render: cart ----------
function renderCartPanel(){
  const body = document.getElementById('cartBody');
  const foot = document.getElementById('cartFoot');
  if(!body) return;
  const cart = getCart();
  const ids = Object.keys(cart);
  if(ids.length === 0){
    body.innerHTML = `<div class="db-empty">
      <p>Sua sacola está vazia.</p>
      <a href="categoria-brincos.html" class="btn btn-gold">Continuar comprando</a>
    </div>`;
    foot.innerHTML = '';
    return;
  }
  let subtotal = 0;
  body.innerHTML = ids.map(id=>{
    const p = PRODUCTS.find(x=>x.id===id);
    if(!p) return '';
    const qty = cart[id];
    subtotal += p.price * qty;
    return `
      <div class="cart-item">
        <div class="ci-thumb">${p.img ? `<img src="${p.img}" alt="${p.name}">` : ''}</div>
        <div class="ci-info">
          <div class="ci-name">${p.name}</div>
          <div class="ci-price">${money(p.price)}</div>
          <div class="ci-qty">
            <button data-qty-minus="${id}">−</button>
            <span>${qty}</span>
            <button data-qty-plus="${id}">+</button>
          </div>
        </div>
        <button class="ci-remove" data-remove="${id}" aria-label="Remover">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" stroke="currentColor" stroke-width="1.3"/></svg>
        </button>
      </div>`;
  }).join('');

  foot.innerHTML = `
    <div class="cart-total"><span>Subtotal</span><span>${money(subtotal)}</span></div>
    <a href="#" class="btn btn-gold" style="width:100%;justify-content:center;" id="cartCheckout">Finalizar pedido</a>
    <button class="btn btn-black outline" style="width:100%;justify-content:center;margin-top:8px;" id="cartClear">Limpar sacola</button>
  `;

  body.querySelectorAll('[data-qty-plus]').forEach(b=>b.addEventListener('click', ()=>changeQty(b.dataset.qtyPlus, 1)));
  body.querySelectorAll('[data-qty-minus]').forEach(b=>b.addEventListener('click', ()=>changeQty(b.dataset.qtyMinus, -1)));
  body.querySelectorAll('[data-remove]').forEach(b=>b.addEventListener('click', ()=>removeFromCart(b.dataset.remove)));
  document.getElementById('cartClear')?.addEventListener('click', ()=>{ setCart({}); renderCartPanel(); });
  document.getElementById('cartCheckout')?.addEventListener('click', (e)=>{
    e.preventDefault();
    e.target.textContent = 'Pedido simulado ✓';
  });
}

// ---------- render: favorites ----------
function renderFavoritesPanel(){
  const body = document.getElementById('favBody');
  if(!body) return;
  const favs = getFavorites();
  if(favs.length === 0){
    body.innerHTML = `<div class="db-empty">
      <p>Você ainda não favoritou nenhum produto.</p>
      <a href="categoria-brincos.html" class="btn btn-gold">Ver produtos</a>
    </div>`;
    return;
  }
  body.innerHTML = favs.map(id=>{
    const p = PRODUCTS.find(x=>x.id===id);
    if(!p) return '';
    return `
      <div class="cart-item">
        <div class="ci-thumb">${p.img ? `<img src="${p.img}" alt="${p.name}">` : ''}</div>
        <div class="ci-info">
          <div class="ci-name">${p.name}</div>
          <div class="ci-price">${money(p.price)}</div>
          <div class="ci-fav-actions">
            <a href="${p.url}">Ver produto</a>
            <button data-add-fav="${id}">Adicionar à sacola</button>
          </div>
        </div>
        <button class="ci-remove" data-unfav="${id}" aria-label="Remover dos favoritos">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14" stroke="currentColor" stroke-width="1.3"/></svg>
        </button>
      </div>`;
  }).join('');
  body.querySelectorAll('[data-add-fav]').forEach(b=>b.addEventListener('click', ()=>{ addToCart(b.dataset.addFav); renderCartPanel(); }));
  body.querySelectorAll('[data-unfav]').forEach(b=>b.addEventListener('click', ()=>{ toggleFavorite(b.dataset.unfav); }));
}

// ---------- render: social cards (with real QR, only when a link exists) ----------
function socialCardHTML(platform, label, iconSvg){
  const url = SOCIAL_LINKS[platform];
  if(!url){
    return `<div class="social-card social-card-pending">
      <div class="sc-icon">${iconSvg}</div>
      <div class="sc-name">${label}</div>
      <div class="sc-pending">Link ainda não configurado</div>
    </div>`;
  }
  const qrSrc = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=12&data=${encodeURIComponent(url)}`;
  return `<div class="social-card">
    <div class="sc-icon">${iconSvg}</div>
    <div class="sc-name">${label}</div>
    <div class="sc-qr"><img src="${qrSrc}" alt="QR Code ${label} DonnaBella" loading="lazy"></div>
    <a class="btn btn-gold sc-btn" href="${url}" target="_blank" rel="noopener">${label === 'WhatsApp' ? 'Falar no WhatsApp' : 'Abrir ' + label}</a>
  </div>`;
}
const ICONS = {
  instagram: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" stroke-width="1.2"/><circle cx="12" cy="12" r="4" stroke="currentColor" stroke-width="1.2"/><circle cx="17.2" cy="6.8" r="1" fill="currentColor"/></svg>',
  tiktok: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M14 3v10.2a3 3 0 11-2.4-2.94V8a5 5 0 105 5V9.8a6.4 6.4 0 003.4 1V7.6a4 4 0 01-3.6-2.2A4 4 0 0116 3h-2z" fill="currentColor"/></svg>',
  whatsapp: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M6 18l1-3.6A7.5 7.5 0 1110 20l-4 1.5z" stroke="currentColor" stroke-width="1.2"/></svg>'
};
function renderSocialGrid(){
  return `<div class="social-grid">
    ${socialCardHTML('instagram','Instagram',ICONS.instagram)}
    ${socialCardHTML('tiktok','TikTok',ICONS.tiktok)}
    ${socialCardHTML('whatsapp','WhatsApp',ICONS.whatsapp)}
  </div>`;
}

// ---------- info modal templates (Central de Atalhos) ----------
const INFO_TEMPLATES = {
  pedidos: {
    title:'Pedidos feitos',
    html:`<div class="db-empty"><p>Você ainda não fez nenhum pedido.</p><a href="categoria-brincos.html" class="btn btn-gold">Fazer pedido agora</a></div>`
  },
  andamento: {
    title:'Pedido em andamento',
    html:`<div class="db-empty"><p>Nenhum pedido em andamento no momento.</p><a href="categoria-brincos.html" class="btn btn-gold">Fazer pedido agora</a></div>`
  },
  cupons: {
    title:'Cupons disponíveis',
    html:`<div class="coupon-list">
      <div class="coupon-item"><b>PRIMEIRA90</b><span>90% OFF na primeira compra · válido até 10/10/2026</span></div>
      <div class="coupon-item"><b>RELAMPAGO15</b><span>15% OFF em toda a loja · válido até 10/10/2026</span></div>
      <div class="coupon-item"><b>OUSADIA20</b><span>20% OFF em óculos · válido até 10/10/2026</span></div>
    </div>`
  },
  cuponsUsados: {
    title:'Cupons utilizados',
    html:`<div class="db-empty"><p>Você ainda não utilizou nenhum cupom.</p></div>`
  },
  atendimento: {
    title:'Central de atendimento',
    html:`<div class="chat-shortcuts">
      <button class="chat-chip">Quero ajuda para escolher um produto</button>
      <button class="chat-chip">Onde está meu pedido?</button>
      <button class="chat-chip">Quero informações sobre pagamento</button>
      <button class="chat-chip">Quero informações sobre entrega</button>
      <button class="chat-chip">Tenho um problema com meu pedido</button>
    </div>
    <div style="margin-top:18px;">${socialCardHTML('whatsapp','WhatsApp',ICONS.whatsapp)}</div>`
  },
  guia: {
    title:'Guia de compra',
    html:`<div class="info-text">
      <p><strong>Materiais:</strong> os brincos da linha inox são feitos em aço inoxidável cirúrgico, hipoalergênico, resistente à água e ao suor — ideais para uso diário sem escurecer.</p>
      <p><strong>Como escolher:</strong> para o dia a dia, prefira peças leves como a linha Petit; para ocasiões especiais, as peças com pedra e as argolas maiores têm mais presença.</p>
      <p><strong>Cuidados gerais:</strong> guarde as peças separadas para evitar atrito, evite contato prolongado com perfume e produtos de limpeza, e seque bem após contato com água.</p>
    </div>`
  },
  faq: {
    title:'Perguntas frequentes',
    html:`<div class="info-text">
      <p><strong>Qual o prazo de troca?</strong> Até 7 dias após o recebimento, produto sem uso e na embalagem original.</p>
      <p><strong>O frete é grátis?</strong> Sim, para compras acima de R$ 149. Abaixo disso, o frete é calculado no fechamento do pedido.</p>
      <p><strong>Quais formas de pagamento vocês aceitam?</strong> Pix, Visa, Mastercard, Elo, American Express e boleto.</p>
      <p><strong>A embalagem vem pronta para presente?</strong> Sim, todo pedido sai com a embalagem DonnaBella inclusa.</p>
    </div>`
  },
  sobre: {
    title:'Sobre a DonnaBella',
    html:`<div class="info-text">
      <p>A DonnaBella nasceu para quem não abre mão de qualidade no detalhe. Cada peça é pensada para durar — no material, no acabamento e no jeito de fazer você se sentir.</p>
      <p>Autenticidade não é tendência para nós — é assinatura.</p>
    </div>`
  },
  privacidade: {
    title:'Política de privacidade',
    html:`<div class="info-text">
      <p>Seus dados pessoais são usados exclusivamente para processar pedidos, atendimento e comunicação sobre suas compras — nunca são vendidos a terceiros.</p>
      <p>Você pode solicitar a exclusão dos seus dados a qualquer momento pelos canais de atendimento.</p>
      <p style="color:var(--muted);font-size:11.5px;">Texto-modelo — recomendamos revisão jurídica antes da publicação oficial.</p>
    </div>`
  },
  redes: {
    title:'Siga a DonnaBella',
    html: () => renderSocialGrid()
  }
};

function openInfo(key){
  const t = INFO_TEMPLATES[key];
  if(!t) return;
  document.getElementById('infoTitle').textContent = t.title;
  document.getElementById('infoBody').innerHTML = typeof t.html === 'function' ? t.html() : t.html;
  openPanel('infoPanel');
  document.querySelectorAll('.chat-chip').forEach(c=>{
    c.addEventListener('click', ()=>{
      const link = SOCIAL_LINKS.whatsapp;
      if(link){ window.open(link + (link.includes('?') ? '&' : '?') + 'text=' + encodeURIComponent(c.textContent), '_blank'); }
    });
  });
}

// ---------- countdown: real 24h cycle, persisted, never negative/stuck ----------
function startCountdown(el){
  if(!el) return;
  const hEl = el.querySelector('[data-h]'), mEl = el.querySelector('[data-m]'), sEl = el.querySelector('[data-s]');
  const CYCLE = 24 * 3600 * 1000;
  let end = Store.get('db_countdown_end', null);
  if(!end || end < Date.now()){
    end = Date.now() + CYCLE;
    Store.set('db_countdown_end', end);
  }
  function tick(){
    let now = Date.now();
    if(end <= now){
      // avança ciclos de 24h até ficar no futuro — nunca fica negativo/travado
      while(end <= now) end += CYCLE;
      Store.set('db_countdown_end', end);
    }
    const remaining = Math.max(0, Math.floor((end - now)/1000));
    const h = Math.floor(remaining/3600), m = Math.floor((remaining%3600)/60), s = remaining%60;
    if(hEl) hEl.textContent = String(h).padStart(2,'0');
    if(mEl) mEl.textContent = String(m).padStart(2,'0');
    if(sEl) sEl.textContent = String(s).padStart(2,'0');
  }
  tick();
  setInterval(tick, 1000);
}

// ---------- price calculator (used on precificador.html) ----------
function calcPricing(inputVal, discountPct=0.6, installments=12){
  const raw = String(inputVal).replace(/\./g,'').replace(',', '.').replace(/[^\d.]/g,'');
  const original = parseFloat(raw);
  if(isNaN(original) || original <= 0){ return null; }
  const discountValue = Math.round(original * discountPct * 100)/100;
  const final = Math.round((original - discountValue)*100)/100;
  const installment = Math.round((final/installments)*100)/100;
  return { original, discountPct, discountValue, final, installment, installments };
}

// ===================== DOM READY =====================
document.addEventListener('DOMContentLoaded', () => {

  injectSharedUI();
  updateCartBadge();
  updateFavoriteHearts();
  renderCartPanel();
  renderFavoritesPanel();

  /* reveal on scroll */
  const revealEls = document.querySelectorAll('.reveal');
  if('IntersectionObserver' in window){
    const io = new IntersectionObserver((entries)=>{
      entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
    }, { threshold:.12 });
    revealEls.forEach(el=>io.observe(el));
  } else { revealEls.forEach(el=>el.classList.add('in')); }

  /* hamburger drawer */
  const drawer = document.getElementById('drawer');
  const overlay = document.getElementById('drawerOverlay');
  const openBtns = document.querySelectorAll('[data-drawer-open]');
  const closeBtns = document.querySelectorAll('[data-drawer-close]');
  const openDrawer = () => { drawer?.classList.add('open'); overlay?.classList.add('open'); document.body.style.overflow='hidden'; };
  const closeDrawer = () => { drawer?.classList.remove('open'); overlay?.classList.remove('open'); document.body.style.overflow=''; };
  openBtns.forEach(b=>b.addEventListener('click', openDrawer));
  closeBtns.forEach(b=>b.addEventListener('click', closeDrawer));
  overlay?.addEventListener('click', closeDrawer);

  /* drawer shortcut wiring: data-open="cart|fav|info:key" */
  document.querySelectorAll('[data-open]').forEach(el=>{
    el.addEventListener('click', (e)=>{
      const val = el.dataset.open;
      closeDrawer();
      if(val === 'cart'){ e.preventDefault(); renderCartPanel(); openPanel('cartPanel'); }
      else if(val === 'fav'){ e.preventDefault(); renderFavoritesPanel(); openPanel('favPanel'); }
      else if(val.startsWith('info:')){ e.preventDefault(); openInfo(val.split(':')[1]); }
    });
  });

  /* header heart = favorites panel, header bag = cart panel */
  document.querySelectorAll('[data-open-fav]').forEach(b=>b.addEventListener('click', (e)=>{ e.preventDefault(); renderFavoritesPanel(); openPanel('favPanel'); }));
  document.querySelectorAll('[data-open-cart]').forEach(b=>b.addEventListener('click', (e)=>{ e.preventDefault(); renderCartPanel(); openPanel('cartPanel'); }));

  /* product-card favorite buttons + add-to-cart CTAs */
  document.querySelectorAll('[data-fav-btn]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{ e.preventDefault(); toggleFavorite(btn.dataset.favBtn); });
  });
  document.querySelectorAll('[data-add-cart]').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      addToCart(btn.dataset.addCart);
      renderCartPanel();
      openPanel('cartPanel');
    });
  });

  /* homepage "Siga a DonnaBella" section */
  const followMount = document.getElementById('socialFollowGrid');
  if(followMount) followMount.innerHTML = renderSocialGrid();

  /* search */
  const searchToggle = document.getElementById('searchToggle');
  const searchPanel = document.getElementById('searchPanel');
  const searchInput = document.getElementById('searchInput');
  const searchResults = document.getElementById('searchResults');
  function renderResults(query){
    if(!searchResults) return;
    searchResults.innerHTML = '';
    const q = query.trim().toLowerCase();
    if(!q){ searchResults.innerHTML = '<div class="search-empty">Digite o nome do produto…</div>'; return; }
    const matches = PRODUCTS.filter(p => p.name.toLowerCase().includes(q));
    if(matches.length === 0){ searchResults.innerHTML = '<div class="search-empty">Nada encontrado para "'+ query.trim() +'". Tente outro termo.</div>'; return; }
    matches.forEach(p=>{
      const a = document.createElement('a');
      a.href = p.url;
      a.innerHTML = `<span>${p.name}</span><span class="sr-price">${money(p.price)}</span>`;
      searchResults.appendChild(a);
    });
  }
  searchToggle?.addEventListener('click', (e)=>{
    e.stopPropagation();
    searchPanel.classList.toggle('open');
    if(searchPanel.classList.contains('open')){ renderResults(''); searchInput?.focus(); }
  });
  searchInput?.addEventListener('input', (e)=> renderResults(e.target.value));
  document.addEventListener('click', (e)=>{
    if(searchPanel && !searchPanel.contains(e.target) && e.target !== searchToggle){ searchPanel.classList.remove('open'); }
  });

  /* category block dropdowns */
  document.querySelectorAll('.cb-toggle').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      e.preventDefault();
      const block = btn.closest('.cat-block');
      const wasOpen = block.classList.contains('open');
      document.querySelectorAll('.cat-block.open').forEach(b=> b!==block && b.classList.remove('open'));
      block.classList.toggle('open', !wasOpen);
    });
  });

  /* filter/sort toggle (category page) */
  const filterToggle = document.getElementById('filterToggle');
  const filterPanel = document.getElementById('filterPanel');
  filterToggle?.addEventListener('click', ()=> filterPanel?.classList.toggle('open'));

  const sortToggle = document.getElementById('sortToggle');
  sortToggle?.addEventListener('click', ()=>{
    const grid = document.getElementById('productGrid');
    if(!grid) return;
    const cards = Array.from(grid.children);
    const asc = sortToggle.dataset.dir !== 'asc';
    cards.sort((a,b)=>{
      const pa = parseFloat(a.dataset.price), pb = parseFloat(b.dataset.price);
      return asc ? pa-pb : pb-pa;
    });
    cards.forEach(c=>grid.appendChild(c));
    sortToggle.dataset.dir = asc ? 'asc' : 'desc';
    sortToggle.querySelector('span').textContent = asc ? 'Menor preço' : 'Maior preço';
  });

  /* hero carousel */
  const track = document.getElementById('heroTrack');
  if(track){
    const slides = track.children.length;
    let idx = 0;
    const dotsWrap = document.getElementById('heroDots');
    const dots = [];
    for(let i=0;i<slides;i++){
      const d = document.createElement('button');
      d.className = 'hero-dot' + (i===0?' active':'');
      d.setAttribute('aria-label', 'Slide ' + (i+1));
      d.addEventListener('click', ()=> go(i));
      dotsWrap.appendChild(d);
      dots.push(d);
    }
    function go(i){
      idx = (i + slides) % slides;
      track.style.transform = `translateX(-${idx*100}%)`;
      dots.forEach((d,n)=> d.classList.toggle('active', n===idx));
      track.querySelectorAll('video').forEach(v=>v.pause());
      const activeVideo = track.children[idx].querySelector('video');
      if(activeVideo){ activeVideo.currentTime = 0; activeVideo.play().catch(()=>{}); }
    }
    document.getElementById('heroPrev')?.addEventListener('click', ()=> go(idx-1));
    document.getElementById('heroNext')?.addEventListener('click', ()=> go(idx+1));

    let touchX = null;
    track.addEventListener('touchstart', e=> touchX = e.touches[0].clientX, {passive:true});
    track.addEventListener('touchend', e=>{
      if(touchX===null) return;
      const dx = e.changedTouches[0].clientX - touchX;
      if(Math.abs(dx) > 40) go(idx + (dx < 0 ? 1 : -1));
      touchX = null;
    }, {passive:true});

    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(!reduceMotion){
      let auto = setInterval(()=> go(idx+1), 5500);
      track.closest('.hero').addEventListener('mouseenter', ()=> clearInterval(auto));
      track.closest('.hero').addEventListener('mouseleave', ()=> auto = setInterval(()=> go(idx+1), 5500));
    }
    const firstVideo = track.children[0].querySelector('video');
    if(firstVideo){ firstVideo.muted = true; firstVideo.playsInline = true; firstVideo.play().catch(()=>{}); }
  }

  /* countdown */
  document.querySelectorAll('[data-countdown]').forEach(el=> startCountdown(el));

  /* floating WhatsApp button */
  const waFloat = document.getElementById('waFloat');
  if(waFloat){
    if(SOCIAL_LINKS.whatsapp){
      waFloat.href = SOCIAL_LINKS.whatsapp;
      waFloat.target = '_blank';
      waFloat.rel = 'noopener';
    } else {
      waFloat.addEventListener('click', (e)=>{ e.preventDefault(); openInfo('redes'); });
    }
  }

  /* price calculator page */
  const priceInput = document.getElementById('precoInput');
  if(priceInput){
    const out = {
      original: document.getElementById('outOriginal'),
      discountPct: document.getElementById('outDiscountPct'),
      discountValue: document.getElementById('outDiscountValue'),
      final: document.getElementById('outFinal'),
      installment: document.getElementById('outInstallment'),
    };
    function render(){
      const r = calcPricing(priceInput.value);
      if(!r){
        out.original.textContent = '—';
        out.discountPct.textContent = '—';
        out.discountValue.textContent = '—';
        out.final.textContent = '—';
        out.installment.textContent = '—';
        return;
      }
      out.original.textContent = money(r.original);
      out.discountPct.textContent = Math.round(r.discountPct*100) + '% OFF';
      out.discountValue.textContent = money(r.discountValue);
      out.final.textContent = money(r.final);
      out.installment.textContent = `${r.installments}x de ${money(r.installment)}`;
    }
    priceInput.addEventListener('input', render);
    render();
  }

});
